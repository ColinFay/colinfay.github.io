# tidystringdist 0.1.0

2018-01

stringsasfactors removed

2017-10-26

Compute several methods is now possible. 

2017-10 

- Col name in output is now the name of the method used. 

* first commit



