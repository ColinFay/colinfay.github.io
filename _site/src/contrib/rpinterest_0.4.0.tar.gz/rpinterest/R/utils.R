`%||%` <- function(a,b) if(is.null(a)) b else a

#' @importFrom attempt stop_if_not
#' @importFrom curl has_internet
check_internet <- function(){
  stop_if_not(.x = has_internet(), msg = "Please check your internet connexion")
}

#' @importFrom httr status_code
check_status <- function(res, msg = "The API returned an error"){
  warn_if_not(.x = status_code(res), 
              .p = ~ .x == 200,
              msg = msg)
}


default <- data.frame(pin_id = vector("character"), 
                      creator_name = vector("character"), 
                      creator_id = vector("character"), 
                      type = vector("character"), 
                      original_link = vector("character"), 
                      pin_note = vector("character"), 
                      pin_color = vector("character"), 
                      pin_link = vector("character"), 
                      pin_board_name = vector("character"), 
                      pin_board_url = vector("character"), 
                      pin_board_id = vector("character"), 
                      pins_likes = vector("character"), 
                      pins_comments = vector("character"), 
                      pins_repins = vector("character"), 
                      attribution_title = vector("character"), 
                      attribution_author = vector("character"), 
                      attribution_url = vector("character"), 
                      attribution_provider = vector("character"), 
                      stringsAsFactors = FALSE)
