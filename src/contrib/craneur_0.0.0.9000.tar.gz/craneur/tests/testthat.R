library(testthat)
library(craneur)

test_check("craneur")
