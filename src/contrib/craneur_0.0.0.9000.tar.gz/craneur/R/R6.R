Craneur <- R6::R6Class("Craneur",
                       public = list(
                         initialize = function(name){
                          self$name <- name
                         },
                         name = character(0),
                         add_package = function(name, path, NeedsCompilation = "no"){
                           parsed <- parse_pkg(name, path)
                           self$packages[[parsed$Package]] <- parsed
                           self$packages[[parsed$Package]][["NeedsCompilation"]] <- NeedsCompilation
                           self$paths[[parsed$Package]] <- path
                         },
                         packages = list(),
                         paths = list(),
                         write = function(path = ".", index = TRUE){
                           save_packages(name = self$name,
                                         pkg = self$packages,
                                         paths = self$paths,
                                         path = path)
                         }
                       ))


#' @importFrom attempt stop_if_not
#' @importFrom tools file_ext md5sum
#' @importFrom utils untar
#' @importFrom desc description

parse_pkg <- function(name, path){
  stop_if_not(path, ~ file_ext(.x) == "gz", "Please provide a tar.gz")
  tmp_dir <- tempdir()
  on.exit(
    unlink(tmp_dir)
  )
  untar(normalizePath(path), exdir = tmp_dir)
  l <- list.files(tmp_dir, all.files = TRUE, recursive = TRUE, full.names = TRUE)
  greped_desc <- description$new(grep(paste0(name, "/","DESCRIPTION"), l, value = TRUE))
  list(
    Package = greped_desc$get("Package"),
    Version = paste(greped_desc$get_version(), sep = "."),
    Imports = greped_desc$get("Imports"),
    Depends = greped_desc$get("Depends"),
    Suggests = greped_desc$get("Suggests"),
    License = greped_desc$get("License"),
    MD5sum = md5sum(path)
    )
}

# parse_pkg("nmviewer","../nmviewer_0.3.0.tar.gz")

one_package <- function(vec){
  vec <- vec[ ! is.na(vec) ]
  paste(names(vec), vec, sep = ": ", collapse = "\n")
}

build_PACKAGES <- function(list){
  paste(lapply(list, one_package), collapse = "\n\n")
}

save_packages <- function(name, pkg, paths, path = ".", build_index = TRUE){
  location <- file.path(normalizePath(path),"src", "contrib")
  dir.create(location, recursive = TRUE, showWarnings = FALSE)
  pkg <- build_PACKAGES(pkg)
  write(pkg, file.path(location, "PACKAGES"))
  file.copy(as.character(paths), location)
  l <- list.files(location, pattern = "tar.gz")
  if (build_index) build_index(l, name, location)
}

#' @importFrom glue glue

build_index <- function(paths, name, location){
  pkg_list <- lapply(paths, function(x){
    glue('<li><a href="{x}">{x}</a></li>')
  })
  html <- glue('<!DOCTYPE html>
        <html lang="en">
        <head>
        <meta charset="utf-8">
        <title>{name} R Archive Network</title>
        </head>
        <body>
        <h2>{name} R Archive Network</h2>
        <p>List of available packages:</p>
        <ul>
        {paste(pkg_list, collapse = "\n")}
        </ul>
        </body>
        </html>')
  write(html, file.path(location, "index.html"))
}


