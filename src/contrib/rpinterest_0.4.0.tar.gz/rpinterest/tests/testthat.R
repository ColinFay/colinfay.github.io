library(testthat)
library(rpinterest)

test_check("rpinterest")
