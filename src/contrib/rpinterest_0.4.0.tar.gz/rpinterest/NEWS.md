# rpinterest 0.4.1

* Deprecated CamelCase functions, moved to snake_case

* Added a `NEWS.md` file to track changes to the package.
