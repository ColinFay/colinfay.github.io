#'Get board pins using board ID
#'
#'Get information about all the pins on a pinterest board using the board ID.
#'
#'Takes a board ID and an access token, returns a data.frame.
#'@param boardID a character string with a board ID.
#'@param token a character string with an access token generated at \url{https://developers.pinterest.com/tools/access_token/}
#'@return Always returns a data.frame, with a warning when appropriate.
#'@export
#'@importFrom httr GET
#'@importFrom rjson fromJSON
#'@importFrom glue glue
#'@importFrom purrr map_df %||%
#'@examples
#'board_pins_by_id(id = "42080646457333782", token = token)

board_pins_by_id <- function(id, token){
  #browser()
  check_internet()
  url <- glue("https://api.pinterest.com/v1/boards/{id}/pins/?access_token={token}&fields=id%2Clink%2Cnote%2Curl%2Cattribution%2Ccolor%2Cboard%2Ccounts%2Ccreated_at%2Ccreator%2Cimage%2Cmedia%2Cmetadata%2Coriginal_link")
  res <- GET(url)
  check_status(res, glue("Your API call returned an error, with a status {res$status_code}"))
  if (res$status_code == 200){
    content <- jsonlite::fromJSON(rawToChar(res$content), simplifyDataFrame = TRUE)
    contentdata <- content$data
    if(!is.null(content$page$`next`)){
      repeat{
        res <- GET(content$page$`next`)
        content <- rjson::fromJSON(rawToChar(res$content))
        contentdata <- c(contentdata, content$data)
        if(is.null(content$page$`next`)){
          break
        }
      }
    }
    identity <- map_df(contentdata, function(obj){
      data.frame(pin_id = obj$id %||% NA, 
                 creator_first_name = obj$creator$first_name %||% NA, 
                 creator_last_name = obj$creator$last_name %||% NA, 
                 creator_id = obj$creator$id %||% NA, 
                 type = obj$media$type %||% NA, 
                 original_link = obj$original_link %||% NA, 
                 pin_note = obj$note %||% NA, 
                 pin_color = obj$color %||% NA, 
                 pin_link = obj$link %||% NA, 
                 pin_board_name = obj$board$name %||% NA, 
                 pin_board_url = obj$board$url %||% NA, 
                 pin_board_id = obj$board$id %||% NA, 
                 pins_likes = obj$counts$likes %||% NA, 
                 pins_comments = obj$counts$comments %||% NA, 
                 pins_repins = obj$counts$repins %||% NA, 
                 attribution_title = obj$attribution$title %||% NA, 
                 attribution_author = obj$attribution$author_name %||% NA, 
                 attribution_url = obj$attribution$author_url %||% NA, 
                 attribution_provider = obj$attribution$provider_name %||% NA, 
                 stringsAsFactors = FALSE)})
    return(identity)
  } else {
    warning("Request error: your token may not be valid, or your input not an actual board ID")
    return(default)
  }
}

#'Get board pins using board name
#'
#'Get information about all the pins on a pinterest board using the board name.
#'
#'Takes a user name, a board name and an access token, returns a data.frame.
#'@param user a character string with a user name.
#'@param board a character string with a board name.
#'@param token a character string with an access token generated at \url{https://developers.pinterest.com/tools/access_token/}
#'@return Always returns a data.frame, with a warning when appropriate.
#'@export
#'@examples
#'board_pins_by_name(user = "colinfay", board = "blanc-mon-amour", token = "your_token")

board_pins_by_name <- function(user, board, token) {
  check_internet()
  url <- glue("https://api.pinterest.com/v1/boards/{id}/pins/?access_token={token}&fields=id%2Clink%2Cnote%2Curl%2Cattribution%2Ccolor%2Cboard%2Ccounts%2Ccreated_at%2Ccreator%2Cimage%2Cmedia%2Cmetadata%2Coriginal_link")
  res <- GET(url)
  check_status(res, glue("Your API call returned an error, with a status {res$status_code}"))
  if (res$status_code == 200){
    content <- rjson::fromJSON(rawToChar(res$content))
    contentdata <- content$data
    if(!is.null(content$page$`next`)){
      repeat{
        res <- GET(content$page$`next`)
        content <- rjson::fromJSON(rawToChar(res$content))
        contentdata <- c(contentdata, content$data)
        if(is.null(content$page$`next`)){
          break
        }
      }
    }
    identity <- map_df(contentdata, function(obj){
      data.frame(pin_id = obj$id %||% NA, 
                 creator_first_name = obj$creator$first_name %||% NA, 
                 creator_last_name = obj$creator$last_name %||% NA, 
                 creator_id = obj$creator$id %||% NA, 
                 type = obj$media$type %||% NA, 
                 original_link = obj$original_link %||% NA, 
                 pin_note = obj$note %||% NA, 
                 pin_color = obj$color %||% NA, 
                 pin_link = obj$link %||% NA, 
                 pin_board_name = obj$board$name %||% NA, 
                 pin_board_url = obj$board$url %||% NA, 
                 pin_board_id = obj$board$id %||% NA, 
                 pins_likes = obj$counts$likes %||% NA, 
                 pins_comments = obj$counts$comments %||% NA, 
                 pins_repins = obj$counts$repins %||% NA, 
                 attribution_title = obj$attribution$title %||% NA, 
                 attribution_author = obj$attribution$author_name %||% NA, 
                 attribution_url = obj$attribution$author_url %||% NA, 
                 attribution_provider = obj$attribution$provider_name %||% NA, 
                 stringsAsFactors = FALSE)
    })
  } else {
    
    warning("Request error: your token may not be valid, or your input not an actual board name")
    return(default)
  }
  return(identity)
}


BoardPinsByID <- function(boardID, token) {
  .Deprecated("board_pins_by_id", msg = 'BoardPinsByID is now deprecated, please use board_pins(by = "id")')
  board_pins_by_id(boardID, token)
}

board_pin_by_name <- function(user, board, token) {
  .Deprecated("board_pins_by_name", msg = 'BoardPinsByID is now deprecated, please use board_pins(by = "id")')
  board_pins_by_name(user, board, token)
}
