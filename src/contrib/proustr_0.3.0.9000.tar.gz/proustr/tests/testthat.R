library(testthat)
library(proustr)

test_check("proustr")
