## ----eval = FALSE--------------------------------------------------------
#  install.packages("languagelayeR")

## ----eval = FALSE--------------------------------------------------------
#  devtools::install_github("ColinFay/languagelayeR")

## ----eval = FALSE--------------------------------------------------------
#  get_lang(query = "I really really love R and that's a good thing, right?", api_key = "your_api_key")

## ----eval = FALSE--------------------------------------------------------
#  get_supported_lang(api_key = "your_api_key")

