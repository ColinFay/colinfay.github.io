#'Get City by Name
#'
#'Get informations about a French city by its name (partial matches possible). Please note that this package works only with French cities.
#'
#'Takes a the name of a French city, returns a data.frame with the available values. Partial matches are possible. In that case, typographic pertinence scores are given, and can be weighted by population with the "boost" argument.
#'@param nom a character string with the name of the city, in full ASCII character. 
#'@param boost a TRUE or FALSE. Default is FALSE. If TRUE, typographic pertinence score will be weighted by population. 
#'@param postal wether or not to include postal codes. Default is FALSE.  
#'@return Returns a data.frame with name(s), INSEE code(s), postal code(s), INSEE department code(s), INSEE region code(s), population (approx), surface(s) (in hectares), lat and long (WGS-84).  
#'@export
#'@examples
#'com_by_name(nom = "Brest")
#'com_by_name(nom = "Rennes", boost = TRUE)
#'com_by_name(nom = "Lo", postal = TRUE)

com_by_name <- function(nom, boost = FALSE, postal = FALSE) {
  check_internet()
  message_if_non_ascii(nom)
  url <- "https://geo.api.gouv.fr/communes?nom="
  if(postal){
    requete <- "nom,code,codesPostaux,codeDepartement,codeRegion,population,centre,surface&format=json&geometry=centre"
  } else {
    requete <- "nom,code,codeDepartement,codeRegion,population,centre,surface&format=json&geometry=centre"
  }
  if(boost){
    url <- paste0(url, nom, "&boost=population&fields=", requete)
  } else {    
    url <- paste0(url, nom, "&fields=", requete)
  }
  ville <- GET(url)
  if (ville$status_code != 200){
    warning("Bad API request (with code", ville$status_code,") : your input may not be an actual name (was ", nom,")")
    if (postal) return(com_default_with_postal)
    if (! postal) return(com_default_no_postal)
  }
  if (ville$status_code == 200){
    content <- rjson::fromJSON(rawToChar(ville$content)) 
    if(length(content) == 0) {
      warning("No Content for that name : your input may not be an actual name (was ", nom,")")
      if (postal) return(com_default_with_postal)
      if (! postal) return(com_default_no_postal)
    } else {
      if(postal){
        identity <- do.call(rbind, lapply(content, turn_with_postal))
      } else {
        identity <- do.call(rbind, lapply(content, turn_without_postal))
      }
    }
    return(identity)
  } 
}

ComByName <- function(nom, boost = FALSE, postal = FALSE) {
  .Deprecated("com_by_name", msg = 'ComByName is now deprecated, please use com_by_name')
  com_by_name(nom, boost, postal)
}

#'Get City by INSEE Code
#'
#'Get informations about a French city by its INSEE code. Please note that this package works only with French cities.
#'
#'Takes an INSEE Code, returns a data.frame with the available values.
#'@param codeInsee numeric vector with an INSEE code.
#'@param postal wether or not to include postal codes. Default is FALSE.
#'@return Returns a data.frame with names, INSEE code, postal code, INSEE department code, INSEE region code, population (approx), surface (in hectares), lat and long (WGS-84). 
#'@export 
#'@importFrom magrittr %>%
#'@importFrom httr GET
#'@importFrom jsonlite fromJSON
#'@importFrom tools showNonASCII
#'@note If you don't know the INSEE code of the city you're looking for, you can find it by using the \code{\link{ComByName}} function.
#'@examples
#' com_by_code(codeInsee = 29019) 
#' com_by_code(codeInsee = 31555, postal = TRUE)
#' com_by_code(codeInsee = com_by_name("Rennes")[1,"codeInsee"])

com_by_code <- function(codeInsee, postal = FALSE) {
  check_internet()
  codeInsee <- add_zero(codeInsee, 5)
  url <- glue("https://geo.api.gouv.fr/communes/{codeInsee}")
  if(postal){
    url <-glue("{url}?fields=nom,code,codesPostaux,codeDepartement,codeRegion,population,centre,surface&format=json&geometry=centre")
  } else {
    url <-glue("{url}?fields=nom,code,codeDepartement,codeRegion,population,centre,surface&format=json&geometry=centre")
  }
  ville <- GET(url)
  if (ville$status_code != 200){
    warning("Bad API request (with code", ville$status_code,") : your input may not be an actual name (was ", nom,")")
    if (postal) return(com_default_with_postal)
    if (! postal) return(com_default_no_postal)
  }
  content <- rjson::fromJSON(rawToChar(ville$content)) 
  if(length(content) == 0) {
    warning("No Content for that name : your input may not be an actual name (was ", nom,")")
    if (postal) return(com_default_with_postal)
    if (! postal) return(com_default_no_postal)
  } else {
    if(postal){
      identity <- turn_with_postal(content)
    } else {
      identity <-turn_without_postal(content)
    }
  }
  return(identity)
}

ComByCode <- function(codeInsee, postal = FALSE) {
  .Deprecated("com_by_code", msg = 'ComByCode is now deprecated, please use com_by_code')
  com_by_code(codeInsee, postal)
}

#'Get City by Coordinates 
#'
#'Get informations about a French city by its Coordinates (WGS-84). Please note that this package works only with French cities.
#'
#'Takes the latitude and longitude of a city, returns a data.frame with the available values.
#'@param lat a character string with latitude (WGS-84) 
#'@param lon a character string with longitude (WGS-84)
#'@param postal wether or not to include postal codes. Default is FALSE.  
#'@return Returns a data.frame with name, INSEE code, postal code, INSEE department code, INSEE region code, population (approx), surface (in hectares), lat and long (WGS-84).
#'@export
#'@note If you don't know the coordinates of the city you're looking for, you can find it by using the \code{\link{ComByName}} function.
#'@examples
#'ComByCoord(lat = "48.11023", lon = "-1.678872") 
#'ComByCoord(lat = "48.74313", lon = "-3.460337", postal = TRUE)

com_by_coord <- function(lat, lon, postal=FALSE) {
  check_internet()
  if(postal){
    url <- glue("https://geo.api.gouv.fr/communes?lon={lon}&lat={lat}&fields=nom,code,codesPostaux,codeDepartement,codeRegion,population,centre,surface&format=json&geometry=centre")
  } else {
    url <- glue("https://geo.api.gouv.fr/communes?lon={lon}&lat={lat}&fields=nom,code,codeDepartement,codeRegion,population,centre,surface&format=json&geometry=centre")
  } 
  ville <- GET(url)
  if (ville$status_code != 200){
    warning("Bad API request (with code", ville$status_code,") : your input may not be actual coordinates (were ", lat," and ", lon, ")")
    if (postal) return(com_default_with_postal)
    if (! postal) return(com_default_no_postal)
  }
  content <- rjson::fromJSON(rawToChar(ville$content)) 
  if(length(content) == 0) {
    warning("No Content for that coordinates : your input may not be actual coordinates (were ", lat," and ", lon, ")")
    if (postal) return(com_default_with_postal)
    if (! postal) return(com_default_no_postal)
  } 
  if(postal){
    return(do.call(rbind, lapply(content, turn_with_postal)))
  } else {
    return(do.call(rbind, lapply(content, turn_without_postal)))
  }
}

ComByCoord <- function(lat, lon, postal=FALSE) {
  .Deprecated("com_by_coord", msg = 'ComByCoord is now deprecated, please use com_by_coord')
  com_by_coord(codeInsee, postal)
}

#'Get Cities by Department 
#'
#'Get informations about all the cities in a French department by its INSEE Code. Please note that this package works only with French cities.
#'
#'Takes a department INSEE Code, returns a data.frame with the available values.
#'@param codeDepartement a numeric vector with a department INSEE Code. 
#'@param postal wether or not to include postal codes. Default is FALSE.  
#'@return Returns a data.frame with names of the cities, INSEE codes, postal codes, INSEE department codes, INSEE region codes, population of the cities (approx), surface of the cities (in hectares), lat and long of the cities (WGS-84). 
#'@export
#'@note If you don't know the INSEE code of the department you're looking for, you can find it by using the \code{\link{DepByName}} function.
#'@examples
#'com_by_dep(codeDepartement = 35) 
#'ComByDep(codeDepartement = 29, postal = TRUE)

com_by_dep <- function(codeDepartement, postal=FALSE) {
  browser()
  check_internet()
  codeDepartement <- add_zero(codeDepartement, 5)
  if(postal){
    url <- glue("https://geo.api.gouv.fr/communes?codeDepartement={codeDepartement}&fields=nom,code,codesPostaux,codeDepartement,codeRegion,population,centre,surface&format=json&geometry=centre")
  } else {
    url <- glue("https://geo.api.gouv.fr/communes?codeDepartement={codeDepartement}&fields=nom,code,codeDepartement,codeRegion,population,centre,surface&format=json&geometry=centre")
  } 
  ville <- GET(url)
  if (ville$status_code != 200){
    warning("Bad API request (with code", ville$status_code,") : your input may not be actual coordinates (were ", lat," and ", lon, ")")
    if (postal) return(com_default_with_postal)
    if (! postal) return(com_default_no_postal)
  }
  content <- rjson::fromJSON(rawToChar(ville$content)) 
  if(length(content) == 0) {
    warning("No Content for that coordinates : your input may not be actual coordinates (were ", lat," and ", lon, ")")
    if (postal) return(com_default_with_postal)
    if (! postal) return(com_default_no_postal)
  } 
  if(postal){
    return(do.call(rbind, lapply(content, turn_with_postal)))
  } else {
    return(do.call(rbind, lapply(content, turn_without_postal)))
  }
}

ComByDep <- function(codeDepartement, postal=FALSE) {
  .Deprecated("com_by_dep", msg = 'ComByCoord is now deprecated, please use com_by_dep')
  com_by_dep(codeDepartement, postal)
}
