`%||%` <- function(a,b) if(is.null(a)) b else a

#' @importFrom attempt stop_if_not
#' @importFrom curl has_internet
check_internet <- function(){
  stop_if_not(.x = has_internet(), msg = "Please check your internet connexion")
}

#' @importFrom httr status_code
check_status <- function(res, msg = "The API returned an error"){
  warn_if_not(.x = status_code(res), 
              .p = ~ .x == 200,
              msg = msg)
}

com_default_with_postal <- data.frame(name = vector("character"), 
                      codeInsee = vector("character"),
                      codesPostaux = vector("character"),
                      codeDepartement = vector("character"),
                      codeRegion = vector("character"),
                      population = vector("character"),
                      surface  = vector("character"),
                      lat  = vector("character"),
                      long = vector("character"), 
                      score = vector("character"))

com_default_no_postal <- data.frame(name = vector("character"), 
                      codeInsee = vector("character"),
                      codeDepartement = vector("character"),
                      codeRegion = vector("character"),
                      population = vector("character"),
                      surface  = vector("character"),
                      lat  = vector("character"),
                      long = vector("character"))

turn_with_postal <- function(obj){
  data.frame(name = obj$nom %||% NA, 
             codeInsee = obj$code %||% NA,
             codesPostaux = obj$codesPostaux %||% NA,
             codeDepartement = obj$codeDepartement %||% NA,
             codeRegion = obj$codeRegion %||% NA,
             population = obj$population %||% NA,
             surface  = obj$surface %||% NA,
             lat  = obj$centre$coordinates [2] %||% NA,
             long = obj$centre$coordinates [1] %||% NA,
             stringsAsFactors = FALSE)
  }

turn_without_postal <- function(obj){
  data.frame(name = obj$nom %||% NA, 
             codeInsee = obj$code %||% NA,
             codeDepartement = obj$codeDepartement %||% NA,
             codeRegion = obj$codeRegion %||% NA,
             population = obj$population %||% NA,
             surface  = obj$surface %||% NA,
             lat  = obj$centre$coordinates [2] %||% NA,
             long = obj$centre$coordinates [1] %||% NA,
             stringsAsFactors = FALSE)
}

add_zero <- function(x, n){
  formatC(x, width = n, format = "d", flag = "0")
}

message_if_non_ascii <- function(nom){
  message_if(length(showNonASCII(nom)) != 0, 
          msg = glue("Your name '{nom}' contains non ASCII character(s), this might impact the accuracy of the result. 
                     Please use only ASCII characters in your function call."))
}

