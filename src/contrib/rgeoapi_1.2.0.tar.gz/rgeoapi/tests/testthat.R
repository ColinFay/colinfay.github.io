library(testthat)
library(rgeoapi)

test_check("rgeoapi")
