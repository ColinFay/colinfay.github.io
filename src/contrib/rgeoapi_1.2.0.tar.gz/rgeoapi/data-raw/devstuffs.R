library(devtools)
library(usethis)
library(desc)
library(glue)
library(httr)
library(attempt)
library(curl)

my_desc <- description$new()
my_desc$bump_version(which = "minor")
my_desc$set("Date",Sys.Date())
my_desc$write()

use_mit_license(name = "Colin FAY")
use_code_of_conduct()
use_readme_rmd()
use_news_md()

use_package("httr")
use_package("jsonlite")
use_package("curl")
use_package("attempt")
use_package("purrr")
use_package("glue")

use_tidy_description()

use_testthat()
use_test("rgeoapi")
